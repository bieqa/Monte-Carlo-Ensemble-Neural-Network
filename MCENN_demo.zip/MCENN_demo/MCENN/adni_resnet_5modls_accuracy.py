"""
Created on Dec 6 2018

Perform geometric cnn for dementia classification using cortical thickness data from 
ADNI dataset. Using ten-fold to defind train and test data sets.
@author: Chaoqiang Liu
Revision: 1.0 

Copyright (C) 2019,
CFA Lab and Dept. of Biomedical Engineering, National University of Singapore. 
All rights reserved.
"""
"""
Input files      : REG_NEIGHBOR_MAT = '../regular/regular_neighborhood_matrix_7.mat'
                   REG_thick_MAT   =  '../regular/adni_thickness_age_gender_regression_regular.mat'
Output directory : save_dir_group0 = '../corthick_age_cn_ad'
"""

import numpy as np
import pandas as pd
import random

import os, time
import datetime
from importlib import reload
import sys
import h5py
import hdf5storage
import scipy.io

srcDIR = "/projects/DeepLearning/chaoqiang/user/imagenet3D2D/DenseNet2dRandom"
sys.path.append(srcDIR)
sys.path.append(srcDIR+"/lib")
sys.path.append(srcDIR+"/architectures")

from lib import helper_func as hf
from lib import load_data as lda
from lib import ADNI2_data_subset as adni


from lib import read_features as rd

modeset=1
filenames=['adni_test_5models_fulltrain_Model',\
           'adni_test_5models_transfer_Model']

numMCDropoutTimes=368#80
NumfoldFeature = 5#20
numTest = 3968
DataPath='/home/chaoqiang/user/imagenet3D2D/ResNet/eval_results/'


DATADIR = '../Data_DenseNet_Input/'
train_valid_test_idx_filename = DATADIR+'train_valid_test_idx/adni_densenet_train_valid_test_idx_cn_ad_r0.mat'
train_valid_test_idx = hdf5storage.loadmat(train_valid_test_idx_filename)
test_idx = train_valid_test_idx['test_idx']      
           
V_Logits0=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest))
V_Logits1=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest))
V_Actual=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest), dtype=np.int64)
for foldFeature in range(5):
    filename = DataPath+filenames[modeset]+str(foldFeature)+'.mat'
    data  =  hdf5storage.loadmat(filename)

#    label[label==2]=1
    logitss = data['logitss']

    V_Actual[foldFeature*numMCDropoutTimes:(foldFeature+1)*numMCDropoutTimes,:] = np.transpose(data['actual'])
    V_Logits0[foldFeature*numMCDropoutTimes:(foldFeature+1)*numMCDropoutTimes,:] = np.transpose(logitss[:,0,:])
    V_Logits1[foldFeature*numMCDropoutTimes:(foldFeature+1)*numMCDropoutTimes,:] = np.transpose(logitss[:,2,:])
V_Actual = V_Actual[:,test_idx]
V_Logits0 = V_Logits0[:,test_idx]
V_Logits1 = V_Logits1[:,test_idx]
V_Actual[V_Actual==2]=1
#idx = [i for i,aa in enumerate(label) if aa ~= 1]
adict0 = {}
adict0['Actual']=V_Actual
adict0['Logits0'] = V_Logits0
adict0['Logits1'] = V_Logits1
pVote368, pAvg368 = hf.P_Average_Accuracy2D(adict0, NumfoldFeature*numMCDropoutTimes,1)
pVote368['acc'] = np.reshape(pVote368['acc'], (5,-1))
pAvg368['acc'] = np.reshape(pAvg368['acc'], (5,-1))
adict0['P_Avg368'] = pAvg368
adict0['P_Vote368'] = pVote368
adict = {}
adict['P_Avg368'] = pAvg368
adict['P_Vote368'] = pVote368
V_Actual = np.reshape(V_Actual, (5,-1))
V_Logits0 = np.reshape(V_Logits0, (5,-1))
V_Logits1 = np.reshape(V_Logits1, (5,-1))
adict['Actual']=V_Actual
adict['Logits0'] = V_Logits0
adict['Logits1'] = V_Logits1
#adict['fcdatas']=V_fcdata
#adict['TrainIdx'] = np.array(train_idx)
#adict['TestIdx'] = np.array(TestIdx)
#adict['TrainSet']=np.array(TrainSet)
#adict['TestSet']=np.array(TestSet)

#pVote, pAvg = hf.P_Average_Accuracy2D(adict, NumfoldFeature*numMCDropoutTimes,1)
pVote, pAvg = hf.P_Average_Accuracy2D(adict, NumfoldFeature,1)
adict['P_Avg'] = pAvg
adict['P_Vote'] = pVote
#adict['SubjID'] = V_SubjID
#adict['IsAttentionSlices'] = IsAttentionSlices
adict['architecture'] = filenames[modeset]
print(pAvg)
print(pVote)


#scipy.io.savemat(RandomInfofilename, adict)    
#hdf5storage.savemat(outputMatfilename, adict);#, format='7.3')
RandomInfofilename = DataPath+filenames[modeset]+'_accuracy.mat'
hdf5storage.write(adict, '.', RandomInfofilename, matlab_compatible=True)


