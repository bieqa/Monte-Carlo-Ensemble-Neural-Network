import os

cuda_device=0 #The indexr of cuda device 0/1/2/3
groupid = 0   #group id 0:CN vs. AD, 1:CN vs. MCI, 2:MCI vs.AD
numMCDropoutRateIndexS=0 #dropout slices 0:1, 1: 1/2, 2:1/4, 3:1/8, 4:1/16,5:1/32
numMCDropoutRateIndexF=0 #dropout feature 0:1, 1: 1/2, 2:1/4, 3:1/8, 4:1/16,5:1/32'

for numMCDropoutRateIndexS in range(6):
    cmd= 'python adni_MCENN.py'+\
             ' --cuda_device='+str(cuda_device)+\
             ' --groupid='+str(groupid)+\
             ' --numMCDropoutRateIndexS='+str(numMCDropoutRateIndexS)+\
             ' --numMCDropoutRateIndexF='+str(numMCDropoutRateIndexF)
    os.system(cmd)
             
for numMCDropoutRateIndexS in range(6):
    cmd= 'python adni_DenseNet.py'+\
             ' --cuda_device='+str(cuda_device)+\
             ' --groupid='+str(groupid)+\
             ' --numMCDropoutRateIndexS='+str(numMCDropoutRateIndexS)+\
             ' --numMCDropoutRateIndexF='+str(numMCDropoutRateIndexF)
    os.system(cmd)