import os
#ADNI CN vs.AD is copied from table3
#Rs:4/8, Rd: 4 is run as following
cuda_device=0 #The indexr of cuda device 0/1/2/3
groupid = 0   #group id 0:CN vs. AD, 1:CN vs. MCI, 2:MCI vs.AD
numMCDropoutRateIndexS=2 #dropout slices 0:1, 1: 1/2, 2:1/4, 3:1/8, 4:1/16,5:1/32
numMCDropoutRateIndexF=0 #dropout feature 0:1, 1: 1/2, 2:1/4, 3:1/8, 4:1/16,5:1/32'

for groupid in range(1,3):
    cmd= 'python adni_MCENN.py'+\
             ' --cuda_device='+str(cuda_device)+\
             ' --groupid='+str(groupid)+\
             ' --numMCDropoutRateIndexS='+str(numMCDropoutRateIndexS)+\
             ' --numMCDropoutRateIndexF='+str(numMCDropoutRateIndexF)
    os.system(cmd)
             
for groupid in range(3):
    cmd= 'python oasis_MCENN.py'+\
             ' --cuda_device='+str(cuda_device)+\
             ' --groupid='+str(groupid)+\
             ' --numMCDropoutRateIndexS='+str(numMCDropoutRateIndexS)+\
             ' --numMCDropoutRateIndexF='+str(numMCDropoutRateIndexF)
    os.system(cmd)
             