"""
Created on Dec 6 2018

Perform geometric cnn for dementia classification using cortical thickness data from 
ADNI dataset. Using ten-fold to defind train and test data sets.
@author: Chaoqiang Liu
Revision: 1.0 

Copyright (C) 2019,
CFA Lab and Dept. of Biomedical Engineering, National University of Singapore. 
All rights reserved.
"""
"""
Input files      : REG_NEIGHBOR_MAT = '../regular/regular_neighborhood_matrix_7.mat'
                   REG_thick_MAT   =  '../regular/adni_thickness_age_gender_regression_regular.mat'
Output directory : save_dir_group0 = '../corthick_age_cn_ad'
"""

import numpy as np
import pandas as pd
import random

import os, time
import datetime
from importlib import reload
import sys
import h5py
import hdf5storage
import scipy.io

srcDIR = "/projects/DeepLearning/chaoqiang/user/imagenet3D2D/DenseNet"
sys.path.append(srcDIR)
sys.path.append(srcDIR+"/lib")
sys.path.append(srcDIR+"/architectures")

from lib import helper_func as hf
from lib import load_data as lda
from lib import ADNI2_data_subset as adni


#from lib import models_3D2D_SS_stopcheck as models
from lib import models_3D2D_SS_StopLaststep as models
from lib import read_features as rd
os.environ["CUDA_VISIBLE_DEVICES"]="1" #GPU1   Test_new

# ~~~~~~~~~~~~~~~~~~~~~~~~ Data type and save folder ~~~~~~~~~~~~~~~~~~~~~~~~ #


groups = ['cn_ad', 'cn_mci', 'mci_ad']
C0ids  = [0, 0, 2]
C1ids  = [3, 2, 3]

groupid = 2 #0: cn_ad, 1: cn_mci, 2: mci_ad
randomstate = 0 # 0 to 9 for 10 random dropout
datasetid = 1 #0 adni, 1:oasis, 2:macc
numMCDropoutRateIndex=2 # 0: 1/2, 1:1/4, 2:1/8, 3:1/16
numMCDropoutTimes=100#80

NumfoldFeature = 5#20


group     = groups[groupid]
C0ID      = C0ids[groupid]
C1ID      = C1ids[groupid]

params = dict()
params['num_epochs']     = 80 #80
#random_direction=3#numslicescut=32, numSelectSlices=64, numSelectFeatures=1024 for one direction
IsAttentionSlices=1
batch_size               = 32

numslicescut=0



DATADIR = '../Data_DenseNet_Input/'

datafilenames = ['adni_all_slices_renset_result_test_model2.mat',\
                 'oasis_all_slices_renset_result_all.mat',\
                 'macc_all_slices_renset_result_all.mat']
datainfofilenames = ['adni_resnet_test_info_V6.mat',\
                 'oasis_resnet_all_info.mat',
                 'macc_info584_V6.mat']
datatypenames = ['adni_',\
                 'oasis_',\
                 'macc_']
MCdropoutnames= ['P2', 'P4', 'P8', 'P16']
train_valid_test_idx_filename = DATADIR+'train_valid_test_idx/'+datatypenames[datasetid]+\
                                'densenet_train_valid_test_idx_'+group+'_r'+str(randomstate)+'.mat'
TransferLearningFromPaths=['adni_cn_ad_r0_SP4_FP1_1637063923_adni_5_100_fc_fixf',\
                           'adni_cn_mci_r0_SP4_FP1_1637753919_adni_5_100_fc_fixf',\
                           'adni_mci_ad_r0_SP4_FP1_1637782357_adni_5_100_fc_fixf']
TransferFromPath = './training_models/'+TransferLearningFromPaths[groupid]                
#szDatetime = datetime.datetime.now().strftime('%s')                                
#outputMatfilename = '../Results_DenseNet/'+datatypenames[datasetid]+group+'_avg2r'+str(randomstate)+'_'+\
#                    MCdropoutnames[numMCDropoutRateIndex]+'_'+szDatetime+'.mat'
#save_dir_group = './training_models/'+datatypenames[datasetid]+group+'_avg2r'+str(randomstate)+'_'+\
#                    MCdropoutnames[numMCDropoutRateIndex]+'_'+szDatetime
szDatetime = datetime.datetime.now().strftime('%s')  
savemat_postfix='_all_in_one_256_5fold_from20slices'#'_all_in_one_256_1fold_from20features'#'_all_in_one_256_1fold_from20slices'#'_all_in_one_2048_5fold'#'_NNM1D_age_last_avg_M3'#'_NNM2D_age_last'#'_fullyconnect_age_gmean'#'_densenet_age' #_fullyconnect_age
outputMatfilename = '../Results_DenseNet/'+datatypenames[datasetid]+'_r'+str(randomstate)+'_transfer_from_'+\
                    TransferLearningFromPaths[groupid*2+randomstate]+savemat_postfix+'.mat'
save_dir_group = './eval_results/'+datatypenames[datasetid]+'_r'+str(randomstate)+'_transfer_from_'+\
                    TransferLearningFromPaths[groupid*2+randomstate]
testing = 0 #for 7199 data set testing=1 to check SubjectType

dataset = datatypenames[datasetid]

#
datafilename = DATADIR + datafilenames[datasetid]
infofilename = DATADIR + datainfofilenames[datasetid]
MCdropoutIndexFilename = DATADIR+'MCdropoutIndex.mat'
#
avg_pool = True
#avg_pool = False # maximum pooling
"""Hyperparameters"""

# Perform data augmentation using mixup
alpha = 0.  # without mixup
#alpha = 0.001  # with mixup


   
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# Graph CNN parameters
test_ratio = 0.15
valid_ratio = 0.25       # portion fof validation data from the original training data
input_norm = True       # Do you want z-score input normalization?
random_batch_sampling_train = False#True#False
gmean_stop = True#False
patient_ratio = .5




if alpha == 0.:
    params['batch_size'] = batch_size
else:
    params['batch_size'] = 2*batch_size


# Number of classes.
C = 2
#
params['random_batch_sampling_train'] = random_batch_sampling_train
params['dropoutmode']    = 2
params['eval_frequency'] = 20#20
params['_inference']     = 'get_model'
params['architecture']   = 'simplefullyconnect'#'simpleNNM1DConv'#'simpleNNM2D' #'simplefullyconnect'#'featurenet2'#'simplefullyconnect'#'featurenet_f'#'vgg'#'googlenet'#'vgg'#'featurenet' #'densenet'

#densenet:batch=32 memory out
params['num_class'] = 2
params['regularization'] = 5e-4
params['dropout']        = 1
params['momentum']       = 0#0.9
params['decay_rate']     = 1#0.5
params['decay_steps']    = 40
params['WD_steps']=[300]
params['WD_values']=[5e-4, 0]
params['LR_steps']=[19,30,44,53]
params['LR_values']=[0.01, 0.005, 0.001, 0.0005, 0.0001]
params['WD_steps']=[300]
params['WD_values']=[5e-4, 0.0]
if params['architecture'] == 'densenet':
    params['depth']=121
elif params['architecture'] == 'featurenet':
    params['depth']=121
elif params['architecture'] == 'featurenet2':
    params['depth']=121
elif params['architecture'] == 'featurenet_f':
    params['depth']=121    
else:
    params['depth']=50

dataInfo  =  hdf5storage.loadmat(infofilename)
train_valid_test_idx = hdf5storage.loadmat(train_valid_test_idx_filename)
test_idx = train_valid_test_idx['test_idx']
train_idx = train_valid_test_idx['train_idx']
valid_idx = train_valid_test_idx['valid_idx']
MCdropoutIndexs = hdf5storage.loadmat(MCdropoutIndexFilename)
MCdropoutIndex2 = MCdropoutIndexs[MCdropoutnames[numMCDropoutRateIndex]+'_IndexSlices']
MCdropoutIndex1 = MCdropoutIndexs[MCdropoutnames[numMCDropoutRateIndex]+'_IndexFeatures']
MCdropoutIndex2 = MCdropoutIndex2[20:,:]
numSelectSlices=MCdropoutIndex2.shape[1]
numSelectFeatures=MCdropoutIndex2.shape[1]
#group = group+'_'+params['architecture']+str(params['dropoutmode'])+str(random_direction)
#
#path = os.path.dirname(os.path.realpath(__file__))
#save_dir_group0 = os.path.join(path, group+'/longitudinal_' + dataset+'_'+group)
#szDatetime = datetime.datetime.now().strftime('%s')
#
#subfoldername='state'+str(randomstate)+'_'+szDatetime
#if numslicescut>0:
#    subfoldername = subfoldername+'_cut'+str(numslicescut)
#subfoldername = subfoldername+'_'+str(params['num_epochs'])
#subfoldername = subfoldername+'_'+str(numMCDropoutTimes)
#if random_direction & 1 :
#    subfoldername = subfoldername+'_'+str(numSelectFeatures)
#if random_direction & 2 :
#    subfoldername = subfoldername+'_'+str(numSelectSlices)
#save_dir_group  = os.path.join(save_dir_group0, subfoldername)
#
#
# ~~~~~~~~~~~~~~~~~~~ Training, validation and test data ~~~~~~~~~~~~~~~~~~~~ #
print('Loading data ...')

data = rd.adni_get_features(datafilename)
#data = rd.adni_data_features_select(data, label1=C0ID, label2=C1ID, subjtypelabel=0, testing=0)
#print('logitss0:'+str(data['logitss0'].shape))
#print('logitss1:'+str(data['logitss1'].shape))
#print('Age:'+str(data['Age'].shape))
#print('Gender:'+str(data['Gender'].shape))
#print('Actual:'+str(data['Actual'].shape))
#print('Subjtype:'+str(data['Subjtype'].shape))
##print('Predicted:'+str(data['Predicted'].shape))
#print('fcdatas:'+str(data['fcdatas'].shape))
#print('SubjID:'+str(len(data['SubjID'])))
#print('Study:'+str(len(data['Study'])))
#print('Viscode:'+str(len(data['Viscode']))) 
#Label = data['Actual']
Age=np.transpose(dataInfo['Age'])
if 'Actual' in list(dataInfo.keys()) :
    Label=np.transpose(dataInfo['Actual'])
else:
    Label=np.transpose(dataInfo['Label'])
Label[Label==C0ID]=0
Label[Label==C1ID]=1
#SubjID = data['SubjID']
SubjID = [dataInfo['SubjID'][0][k][0] for k in range(dataInfo['SubjID'].shape[1])]

thick_select = data['fcdatas']
thick_select = np.expand_dims(thick_select, axis=3)

if numslicescut>0:
    thick_select = thick_select[:,:,numslicescut:-numslicescut,:]

#params['imagesize']            = thick_select.shape[1:]
#print(thick_select.shape)
#SubjIDIndex = adni.adni_generate_unique_SubjId(SubjID)
#C0, C1 = adni.adni_set_class_define(Label, SubjIDIndex)

Labelfilename   = os.path.join(save_dir_group, 'label.csv')
Accuaryfilename = os.path.join(save_dir_group, 'performance.csv')
#RandomInfofilename = os.path.join(save_dir_group, '_randominfo.mat')
Resultfilename  = os.path.join(save_dir_group, '_performance_avg.csv')

all_start_time = time.time()

thick_select0 = thick_select
foldID = 0
#TrainIdx, TestIdx, TrainSet, TestSet = adni.adni_tenfold(Label, SubjIDIndex, C0, C1, randomstate, foldID)
#TrainIdx, TestIdx, TrainSet, TestSet = adni.adni_seperate_training_testing_dataset(Label, SubjIDIndex, C0, C1, randomstate, 0.5)

#
my_list1 = list(range(0,thick_select0.shape[1]))
my_list2 = list(range(0,thick_select0.shape[2]))
numTest=len(test_idx)
V_Idx=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest), dtype=np.int64)
V_Actual=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest), dtype=np.int64)
V_Predicted=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest), dtype=np.int64)
V_Logits0=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest))
V_Logits1=np.zeros((NumfoldFeature*numMCDropoutTimes, numTest))
V_SubjID =  [SubjID[k] for k in test_idx] #SubjID[TestSet]
slice_distri=scipy.io.loadmat('./data/slice_distribution.mat')
slice_distri = slice_distri['distribution']
slice_distri = slice_distri[:,0]
cutTest_idx=[]
idxA=[]

for foldFeature in range(NumfoldFeature):
    data_train, Label_train, data_test, Label_test, data_valid, Label_valid = \
        adni.MCdropout_select_data(thick_select0, Label, Age, train_idx, valid_idx, test_idx, MCdropoutIndex1, MCdropoutIndex2, numMCDropoutTimes, foldFeature=foldFeature)

        
    save_dir = os.path.join(TransferFromPath, str(foldFeature))
    params['dir_name']       = save_dir  
    params['imagesize']      = data_train.shape[1:]
    print(thick_select.shape)
    
    input_test_target = np.transpose(np.vstack([np.transpose(1-Label_test), np.transpose(Label_test)]))
    target_train = np.transpose(np.vstack([np.transpose(1-Label_train), np.transpose(Label_train)]))
    target_valid = np.transpose(np.vstack([np.transpose(1-Label_valid), np.transpose(Label_valid)]))

    print('Sphere shape for train data: ', data_train.shape)
    print('Sphere shape for test data: ', data_test.shape)

    if alpha > 0.:
        target_test = np.copy(input_test_target)
    else:
        target_test = np.copy(input_test_target[:,1])
    target_test = target_test.astype(np.uint8)

    data_train = data_train.astype(np.float32)
    data_valid = data_valid.astype(np.float32)

    if alpha > 0.:
        target_train = np.copy(target_train)
        target_valid = np.copy(target_valid)
    else:
        target_train = np.copy(target_train[:,1])
        target_valid = np.copy(target_valid[:,1])
    target_train = target_train.astype(np.uint8)
    target_valid = target_valid.astype(np.uint8)

    print('Input label shape: ', target_train.shape)

    d       = data_train.shape[1]       # Dimensionality.
    n_train = data_train.shape[0]       # Number of train samples.

    params['decay_steps']    = (np.multiply(params['decay_steps'], n_train / params['batch_size'])).astype(int)
    
    c = np.unique(target_train)   # Number of feature communities (classes).
    
    print('Class imbalance: ', np.unique(target_train, return_counts=True)[1])
    print('Dimensionality: ', d)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ Graph ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #


# Training and validation 0.8
    if alpha > 0.:
        #model = models.cfullconnection_liucq(C, **params)
        model = models.cgcnn_liucq(**params)
    else:
        #model = models.cfullconnection_liucq(1, **params)
        model = models.cgcnn_liucq(**params)
    if 0:
        val_loss_list, val_accuracy_list, val_fscore_list, val_sensitivity_list, val_specificity_list, val_precision_list, val_ppv_list, val_npv_list, val_gmean_list = model.fit(data_train, target_train, data_valid, target_valid, alpha, patient_ratio=patient_ratio, gmean_stop=gmean_stop)

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ #
# Evaluate performance on test set
    prevalence = np.sum(target_test)*1.0 / target_test.shape[0]

    res, logitss, fc_datas, predictions, loss, accuracy, f1, sensitivity, specificity, precision, ppv, npv, gmean = model.evaluate(data_test, target_test)
    hf.save_to_csv(szDatetime, accuracy, f1, sensitivity, specificity, precision, ppv, npv, gmean, Accuaryfilename, dataset, mode='a+', header=(foldID==0))
    hf.print_classification_performance(dataset, prevalence, loss, accuracy, f1, sensitivity, specificity, precision, ppv, npv, gmean)
 
    if alpha > 0.:
        d = {'Idx':np.repeat(test_idx, numMCDropoutTimes, axis=0), 'Actual':target_test[:,1], 'Predicted':predictions, 'Logits0':logitss[:,0],'Logits1':logitss[:,1]}
    else:
        d = {'Idx':np.repeat(test_idx, numMCDropoutTimes, axis=0), 'Actual':target_test, 'Predicted':predictions, 'Logits0':logitss[:,0],'Logits1':logitss[:,1]}
#    df_label = pd.DataFrame(data=d, dtype=np.uint16)
#    df_label.to_csv(os.path.join(save_dir, dataset + '_' + group + '_label.csv'))

    df_labelgroup = pd.DataFrame(data=d)
    df_labelgroup.to_csv(Labelfilename, mode='a+', header=(foldID==0))
    del model
    del df_labelgroup
    del d
    print('processed fold ID:', foldID)
    for foldID in range(numMCDropoutTimes):    
        V_Idx[foldFeature*numMCDropoutTimes+foldID,:]=np.array(test_idx, dtype=np.int64)
        V_Actual[foldFeature*numMCDropoutTimes+foldID,:] = np.array(target_test[numTest*foldID:numTest*(foldID+1)], dtype=np.int64)
        V_Predicted[foldFeature*numMCDropoutTimes+foldID,:] = np.array(predictions[numTest*foldID:numTest*(foldID+1)], dtype=np.int64)
        V_Logits0[foldFeature*numMCDropoutTimes+foldID,:] = np.array(logitss[numTest*foldID:numTest*(foldID+1),0])
        V_Logits1[foldFeature*numMCDropoutTimes+foldID,:] = np.array(logitss[numTest*foldID:numTest*(foldID+1),1])

all_time = float(time.time() - all_start_time)
format_str = 'whole time: %.3f, epoch time: %.3f'
print (format_str % (all_time, all_time/params['num_epochs']))

adict = {}
#adict['Idx'] = np.array(V.Idx)
#adict['Actual']=np.array(V.Actual)
#adict['Predicted'] = np.array(V.Predicted)
#adict['Logits0'] = np.array(V.Logits0)
#adict['Logits1'] = np.array(V.Logits1)

adict['Idx'] = V_Idx
adict['Actual']=V_Actual
adict['Predicted'] = V_Predicted
adict['Logits0'] = V_Logits0
adict['Logits1'] = V_Logits1
#adict['fcdatas']=V_fcdata
#adict['TrainIdx'] = np.array(train_idx)
#adict['TestIdx'] = np.array(TestIdx)
#adict['TrainSet']=np.array(TrainSet)
#adict['TestSet']=np.array(TestSet)
pVote, pAvg = hf.P_Average_Accuracy(adict)
adict['P_Avg'] = pAvg
adict['P_Vote'] = pVote
adict['SubjID'] = V_SubjID
adict['IsAttentionSlices'] = IsAttentionSlices
adict['architecture'] = params['architecture']
print(pAvg)
print(pVote)
#scipy.io.savemat(RandomInfofilename, adict)    
hdf5storage.savemat(outputMatfilename, adict);#, format='7.3')
#hdf5storage.write(adict, '.', RandomInfofilename, matlab_compatible=True)
#t=hdf5storage.loadmat(RandomInfofilename)

